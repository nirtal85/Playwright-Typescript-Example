window.adBlockEnabled = false;
